import os
import logging
import asyncio
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional
import httpx
from datetime import datetime

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI()
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

BOT_TOKEN  = os.environ["BOT_TOKEN"]
API_SECRET = os.environ.get("API_SECRET", "changeme")

# ── Recipients: add Telegram chat_ids separated by comma in env var
# Example: NOTIFY_USERS=123456789,987654321,555000111
_raw_users = os.environ.get("NOTIFY_USERS", os.environ.get("ADMIN_CHAT_ID", ""))
NOTIFY_USERS: List[str] = [u.strip() for u in _raw_users.split(",") if u.strip()]

# ── In-memory order storage ────────────────────────────────────
orders: dict = {}

# ── Telegram helper ────────────────────────────────────────────
async def tg_send(text: str):
    """Send message to ALL configured users"""
    async with httpx.AsyncClient() as client:
        for user_id in NOTIFY_USERS:
            try:
                await client.post(
                    f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage",
                    json={"chat_id": user_id, "text": text, "parse_mode": "Markdown"},
                    timeout=10
                )
            except Exception as e:
                logger.error(f"Failed to send to {user_id}: {e}")

async def tg_send_to(chat_id: str, text: str):
    """Send message to a specific user"""
    async with httpx.AsyncClient() as client:
        await client.post(
            f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage",
            json={"chat_id": chat_id, "text": text, "parse_mode": "Markdown"},
            timeout=10
        )

# ── Blockchain balance checkers ────────────────────────────────

async def check_btc(address: str, expected: float) -> Optional[float]:
    try:
        async with httpx.AsyncClient() as c:
            r = await c.get(f"https://blockstream.info/api/address/{address}", timeout=10)
            if r.status_code == 200:
                data = r.json()
                balance = data.get("chain_stats", {}).get("funded_txo_sum", 0) / 1e8
                return balance if balance >= expected * 0.95 else None
    except Exception as e:
        logger.error(f"BTC check error: {e}")
    return None

async def check_eth_erc20(address: str, expected: float, coin: str) -> Optional[float]:
    try:
        async with httpx.AsyncClient() as c:
            if coin == "ETH":
                r = await c.get(
                    f"https://api.etherscan.io/api?module=account&action=balance&address={address}&tag=latest",
                    timeout=10
                )
                if r.status_code == 200:
                    balance = int(r.json().get("result", 0)) / 1e18
                    return balance if balance >= expected * 0.95 else None
            else:
                contract = "0xdac17f958d2ee523a2206206994597c13d831ec7"
                r = await c.get(
                    f"https://api.etherscan.io/api?module=account&action=tokenbalance"
                    f"&contractaddress={contract}&address={address}&tag=latest",
                    timeout=10
                )
                if r.status_code == 200:
                    balance = int(r.json().get("result", 0)) / 1e6
                    return balance if balance >= expected * 0.95 else None
    except Exception as e:
        logger.error(f"ETH check error: {e}")
    return None

async def check_trx_trc20(address: str, expected: float, coin: str) -> Optional[float]:
    try:
        async with httpx.AsyncClient() as c:
            r = await c.get(f"https://apilist.tronscanapi.com/api/accountv2?address={address}", timeout=10)
            if r.status_code == 200:
                data = r.json()
                if coin == "TRX":
                    balance = data.get("balance", 0) / 1e6
                    return balance if balance >= expected * 0.95 else None
                else:
                    tokens = data.get("trc20token_balances", [])
                    usdt = next((t for t in tokens if t.get("tokenAbbr") == "USDT"), None)
                    if usdt:
                        balance = float(usdt.get("balance", 0)) / 1e6
                        return balance if balance >= expected * 0.95 else None
    except Exception as e:
        logger.error(f"TRX check error: {e}")
    return None

async def check_sol(address: str, expected: float) -> Optional[float]:
    try:
        async with httpx.AsyncClient() as c:
            r = await c.post(
                "https://api.mainnet-beta.solana.com",
                json={"jsonrpc": "2.0", "id": 1, "method": "getBalance", "params": [address]},
                timeout=10
            )
            if r.status_code == 200:
                balance = r.json().get("result", {}).get("value", 0) / 1e9
                return balance if balance >= expected * 0.95 else None
    except Exception as e:
        logger.error(f"SOL check error: {e}")
    return None

async def check_ltc(address: str, expected: float) -> Optional[float]:
    try:
        async with httpx.AsyncClient() as c:
            r = await c.get(f"https://api.blockcypher.com/v1/ltc/main/addrs/{address}/balance", timeout=10)
            if r.status_code == 200:
                balance = r.json().get("balance", 0) / 1e8
                return balance if balance >= expected * 0.95 else None
    except Exception as e:
        logger.error(f"LTC check error: {e}")
    return None

async def check_doge(address: str, expected: float) -> Optional[float]:
    try:
        async with httpx.AsyncClient() as c:
            r = await c.get(f"https://api.blockcypher.com/v1/doge/main/addrs/{address}/balance", timeout=10)
            if r.status_code == 200:
                balance = r.json().get("balance", 0) / 1e8
                return balance if balance >= expected * 0.95 else None
    except Exception as e:
        logger.error(f"DOGE check error: {e}")
    return None

async def check_xrp(address: str, expected: float) -> Optional[float]:
    try:
        async with httpx.AsyncClient() as c:
            r = await c.post(
                "https://xrplcluster.com/",
                json={"method": "account_info", "params": [{"account": address, "ledger_index": "validated"}]},
                timeout=10
            )
            if r.status_code == 200:
                balance = float(r.json().get("result", {}).get("account_data", {}).get("Balance", 0)) / 1e6
                return balance if balance >= expected * 0.95 else None
    except Exception as e:
        logger.error(f"XRP check error: {e}")
    return None

async def check_ton(address: str, expected: float) -> Optional[float]:
    try:
        async with httpx.AsyncClient() as c:
            r = await c.get(f"https://tonapi.io/v2/accounts/{address}", timeout=10)
            if r.status_code == 200:
                balance = r.json().get("balance", 0) / 1e9
                return balance if balance >= expected * 0.95 else None
    except Exception as e:
        logger.error(f"TON check error: {e}")
    return None

async def check_payment(coin: str, address: str, amount: float) -> Optional[float]:
    coin = coin.upper().replace(" ", "_")
    if coin == "BTC":
        return await check_btc(address, amount)
    elif coin in ("ETH", "ETH_ERC20"):
        return await check_eth_erc20(address, amount, "ETH")
    elif coin in ("USDT_ERC", "USDT_ERC20"):
        return await check_eth_erc20(address, amount, "USDT_ERC")
    elif coin in ("USDT_TRC", "USDT_TRC20"):
        return await check_trx_trc20(address, amount, "USDT_TRC")
    elif coin in ("TRX", "TRON_TRX"):
        return await check_trx_trc20(address, amount, "TRX")
    elif coin in ("SOL", "SOLANA_SOL"):
        return await check_sol(address, amount)
    elif coin == "LTC":
        return await check_ltc(address, amount)
    elif coin == "DOGE":
        return await check_doge(address, amount)
    elif coin == "XRP":
        return await check_xrp(address, amount)
    elif coin == "TON":
        return await check_ton(address, amount)
    elif coin in ("BNB", "BNB_BEP20", "LINK", "LINK_ERC20", "DAI", "DAI_ERC20"):
        return await check_eth_erc20(address, amount, "ETH")
    return None

# ── Background checker — every 30 seconds ─────────────────────
async def payment_checker():
    while True:
        await asyncio.sleep(30)
        pending = {k: v for k, v in orders.items() if v["status"] == "pending"}
        for code, order in pending.items():
            try:
                received = await check_payment(
                    order["coin"],
                    order["deposit_address"],
                    float(order["amount"])
                )
                if received is not None:
                    orders[code]["status"] = "received"
                    await tg_send(
                        f"✅ *Payment Received!*\n\n"
                        f"🪙 *Coin:* {order['coin']}\n"
                        f"💰 *Received:* {received:.6f} (expected {order['amount']})\n"
                        f"🔑 *Session:* `{code}`\n"
                        f"📬 *Deposit address:* `{order['deposit_address']}`"
                    )
                    logger.info(f"Payment confirmed: {code}")
            except Exception as e:
                logger.error(f"Checker error for {code}: {e}")

@app.on_event("startup")
async def startup():
    asyncio.create_task(payment_checker())
    logger.info(f"Payment checker started (30s interval). Notifying users: {NOTIFY_USERS}")

# ── API endpoint ───────────────────────────────────────────────
class Addr(BaseModel):
    address: str
    pct: str

class MixPayload(BaseModel):
    secret:          str
    coin:            str
    amount:          str
    delay:           str
    session_code:    str
    deposit_address: str
    addresses:       List[Addr]

@app.post("/api/notify")
async def notify(data: MixPayload):
    if data.secret != API_SECRET:
        raise HTTPException(status_code=403, detail="Forbidden")

    orders[data.session_code] = {
        "coin":            data.coin,
        "amount":          data.amount,
        "deposit_address": data.deposit_address,
        "addresses":       [{"address": a.address, "pct": a.pct} for a in data.addresses],
        "status":          "pending",
        "created_at":      datetime.utcnow().isoformat(),
    }

    addr_text = "\n".join(
        f"  {i+1}. `{a.address}` — {a.pct}"
        for i, a in enumerate(data.addresses)
    ) or "  —"

    await tg_send(
        f"🔀 *New Mix Request!*\n\n"
        f"🪙 *Coin:* {data.coin}\n"
        f"💰 *Amount:* {data.amount}\n"
        f"⏱ *Delay:* {data.delay}h\n"
        f"🔑 *Session:* `{data.session_code}`\n"
        f"📥 *Deposit address:* `{data.deposit_address}`\n\n"
        f"📬 *Recipient addresses:*\n{addr_text}\n\n"
        f"⏳ _Watching blockchain every 30s..._"
    )
    return {"ok": True}

@app.get("/")
def health():
    return {"status": "ok", "orders": len(orders), "notify_users": len(NOTIFY_USERS)}


# ── In-memory order storage ────────────────────────────────────
# { session_code: { coin, amount, deposit_address, status, created_at } }
orders: dict = {}

# ── Telegram helper ────────────────────────────────────────────
async def tg_send(text: str):
    async with httpx.AsyncClient() as client:
        await client.post(
            f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage",
            json={"chat_id": ADMIN_ID, "text": text, "parse_mode": "Markdown"},
            timeout=10
        )

# ── Blockchain balance checkers ────────────────────────────────

async def check_btc(address: str, expected: float) -> Optional[float]:
    """Check BTC address balance via blockstream.info"""
    try:
        async with httpx.AsyncClient() as c:
            r = await c.get(f"https://blockstream.info/api/address/{address}", timeout=10)
            if r.status_code == 200:
                data = r.json()
                # funded_txo_sum in satoshis
                balance_sat = data.get("chain_stats", {}).get("funded_txo_sum", 0)
                balance_btc = balance_sat / 1e8
                return balance_btc if balance_btc >= expected * 0.95 else None
    except Exception as e:
        logger.error(f"BTC check error: {e}")
    return None

async def check_eth_usdt_erc20(address: str, expected: float, coin: str) -> Optional[float]:
    """Check ETH/ERC20 balance via etherscan-compatible API (no key needed for basic)"""
    try:
        async with httpx.AsyncClient() as c:
            if coin == "ETH":
                r = await c.get(
                    f"https://api.etherscan.io/api?module=account&action=balance&address={address}&tag=latest",
                    timeout=10
                )
                if r.status_code == 200:
                    data = r.json()
                    balance = int(data.get("result", 0)) / 1e18
                    return balance if balance >= expected * 0.95 else None
            else:
                # USDT ERC20 contract
                contract = "0xdac17f958d2ee523a2206206994597c13d831ec7"
                r = await c.get(
                    f"https://api.etherscan.io/api?module=account&action=tokenbalance"
                    f"&contractaddress={contract}&address={address}&tag=latest",
                    timeout=10
                )
                if r.status_code == 200:
                    data = r.json()
                    balance = int(data.get("result", 0)) / 1e6
                    return balance if balance >= expected * 0.95 else None
    except Exception as e:
        logger.error(f"ETH check error: {e}")
    return None

async def check_trx_usdt_trc20(address: str, expected: float, coin: str) -> Optional[float]:
    """Check TRX/USDT TRC20 via tronscan"""
    try:
        async with httpx.AsyncClient() as c:
            r = await c.get(
                f"https://apilist.tronscanapi.com/api/accountv2?address={address}",
                timeout=10
            )
            if r.status_code == 200:
                data = r.json()
                if coin == "TRX":
                    balance = data.get("balance", 0) / 1e6
                    return balance if balance >= expected * 0.95 else None
                else:
                    # USDT TRC20
                    tokens = data.get("trc20token_balances", [])
                    usdt = next((t for t in tokens if t.get("tokenAbbr") == "USDT"), None)
                    if usdt:
                        balance = float(usdt.get("balance", 0)) / 1e6
                        return balance if balance >= expected * 0.95 else None
    except Exception as e:
        logger.error(f"TRX check error: {e}")
    return None

async def check_sol(address: str, expected: float) -> Optional[float]:
    """Check SOL balance via Solana public RPC"""
    try:
        async with httpx.AsyncClient() as c:
            r = await c.post(
                "https://api.mainnet-beta.solana.com",
                json={"jsonrpc": "2.0", "id": 1, "method": "getBalance", "params": [address]},
                timeout=10
            )
            if r.status_code == 200:
                data = r.json()
                balance = data.get("result", {}).get("value", 0) / 1e9
                return balance if balance >= expected * 0.95 else None
    except Exception as e:
        logger.error(f"SOL check error: {e}")
    return None

async def check_ltc(address: str, expected: float) -> Optional[float]:
    """Check LTC via blockcypher"""
    try:
        async with httpx.AsyncClient() as c:
            r = await c.get(f"https://api.blockcypher.com/v1/ltc/main/addrs/{address}/balance", timeout=10)
            if r.status_code == 200:
                data = r.json()
                balance = data.get("balance", 0) / 1e8
                return balance if balance >= expected * 0.95 else None
    except Exception as e:
        logger.error(f"LTC check error: {e}")
    return None

async def check_doge(address: str, expected: float) -> Optional[float]:
    """Check DOGE via blockcypher"""
    try:
        async with httpx.AsyncClient() as c:
            r = await c.get(f"https://api.blockcypher.com/v1/doge/main/addrs/{address}/balance", timeout=10)
            if r.status_code == 200:
                data = r.json()
                balance = data.get("balance", 0) / 1e8
                return balance if balance >= expected * 0.95 else None
    except Exception as e:
        logger.error(f"DOGE check error: {e}")
    return None

async def check_xrp(address: str, expected: float) -> Optional[float]:
    """Check XRP via xrplf public API"""
    try:
        async with httpx.AsyncClient() as c:
            r = await c.post(
                "https://xrplcluster.com/",
                json={"method": "account_info", "params": [{"account": address, "ledger_index": "validated"}]},
                timeout=10
            )
            if r.status_code == 200:
                data = r.json()
                balance = float(data.get("result", {}).get("account_data", {}).get("Balance", 0)) / 1e6
                return balance if balance >= expected * 0.95 else None
    except Exception as e:
        logger.error(f"XRP check error: {e}")
    return None

async def check_ton(address: str, expected: float) -> Optional[float]:
    """Check TON via tonapi"""
    try:
        async with httpx.AsyncClient() as c:
            r = await c.get(f"https://tonapi.io/v2/accounts/{address}", timeout=10)
            if r.status_code == 200:
                data = r.json()
                balance = data.get("balance", 0) / 1e9
                return balance if balance >= expected * 0.95 else None
    except Exception as e:
        logger.error(f"TON check error: {e}")
    return None

# ── Route checker to right function ───────────────────────────
async def check_payment(coin: str, address: str, amount: float) -> Optional[float]:
    coin = coin.upper()
    if coin == "BTC":
        return await check_btc(address, amount)
    elif coin in ("ETH", "ETH ERC20"):
        return await check_eth_usdt_erc20(address, amount, "ETH")
    elif coin in ("USDT_ERC", "USDT ERC20"):
        return await check_eth_usdt_erc20(address, amount, "USDT_ERC")
    elif coin in ("USDT_TRC", "USDT TRC20"):
        return await check_trx_usdt_trc20(address, amount, "USDT_TRC")
    elif coin in ("TRX", "TRON TRX"):
        return await check_trx_usdt_trc20(address, amount, "TRX")
    elif coin in ("SOL", "SOLANA SOL"):
        return await check_sol(address, amount)
    elif coin == "LTC":
        return await check_ltc(address, amount)
    elif coin == "DOGE":
        return await check_doge(address, amount)
    elif coin == "XRP":
        return await check_xrp(address, amount)
    elif coin == "TON":
        return await check_ton(address, amount)
    # BNB, LINK, DAI — ERC20 tokens, use ETH address checker
    elif coin in ("BNB", "BNB BEP20", "LINK", "LINK ERC20", "DAI", "DAI ERC20"):
        return await check_eth_usdt_erc20(address, amount, "ETH")
    return None

# ── Background checker loop ────────────────────────────────────
async def payment_checker():
    """Runs every 2 minutes, checks all pending orders"""
    while True:
        await asyncio.sleep(120)  # check every 2 minutes
        pending = {k: v for k, v in orders.items() if v["status"] == "pending"}
        for code, order in pending.items():
            try:
                received = await check_payment(
                    order["coin"],
                    order["deposit_address"],
                    float(order["amount"])
                )
                if received is not None:
                    orders[code]["status"] = "received"
                    await tg_send(
                        f"✅ *Payment Received!*\n\n"
                        f"🪙 *Coin:* {order['coin']}\n"
                        f"💰 *Amount:* {received:.6f} (expected {order['amount']})\n"
                        f"🔑 *Session:* `{code}`\n"
                        f"📬 *Address:* `{order['deposit_address']}`"
                    )
                    logger.info(f"Payment confirmed for {code}")
            except Exception as e:
                logger.error(f"Checker error for {code}: {e}")

@app.on_event("startup")
async def startup():
    asyncio.create_task(payment_checker())
    logger.info("Payment checker started")

# ── API endpoint ───────────────────────────────────────────────
class Addr(BaseModel):
    address: str
    pct: str

class MixPayload(BaseModel):
    secret:          str
    coin:            str
    amount:          str
    delay:           str
    session_code:    str
    deposit_address: str
    addresses:       List[Addr]

@app.post("/api/notify")
async def notify(data: MixPayload):
    if data.secret != API_SECRET:
        raise HTTPException(status_code=403, detail="Forbidden")

    # Save order for blockchain monitoring
    orders[data.session_code] = {
        "coin":            data.coin,
        "amount":          data.amount,
        "deposit_address": data.deposit_address,
        "addresses":       [{"address": a.address, "pct": a.pct} for a in data.addresses],
        "status":          "pending",
        "created_at":      datetime.utcnow().isoformat(),
    }

    addr_text = "\n".join(
        f"  {i+1}. `{a.address}` — {a.pct}"
        for i, a in enumerate(data.addresses)
    ) or "  —"

    msg = (
        f"🔀 *New Mix Request!*\n\n"
        f"🪙 *Coin:* {data.coin}\n"
        f"💰 *Amount:* {data.amount}\n"
        f"⏱ *Delay:* {data.delay}h\n"
        f"🔑 *Session:* `{data.session_code}`\n"
        f"📥 *Deposit address:* `{data.deposit_address}`\n\n"
        f"📬 *Recipient addresses:*\n{addr_text}\n\n"
        f"⏳ _Watching blockchain for payment..._"
    )

    await tg_send(msg)
    return {"ok": True}

@app.get("/")
def health():
    return {"status": "ok", "orders": len(orders)}
